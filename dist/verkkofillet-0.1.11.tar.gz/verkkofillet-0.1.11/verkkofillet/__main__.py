from __future__ import annotations

from .cli import console_main

console_main()