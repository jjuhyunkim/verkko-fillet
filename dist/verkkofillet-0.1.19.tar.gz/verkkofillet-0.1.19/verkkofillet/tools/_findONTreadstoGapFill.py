def findmissONTreads(obj, ):
    """
    Find ONT reads that are not used in gap filling
    """
    